const Post = require('../models/Post');

exports.create = function (title, keyword, location, dateOfCreation, image, description, userId) {
    
    let post = new Post({
        title, 
        keyword, 
        location, 
        dateOfCreation, 
        image, 
        description,
        author: userId,
    });

    return post.save();

};

exports.getAllPosts = () => Post.find().lean();

exports.getPostById = (postId) => {
    return Post.findById(postId)
    .populate('author')
    .populate('votesOnPost')
    .lean(); 
};

exports.voteUp = async (userId, postId) => {
    
    let post = await Post.findById(postId);
    console.log(post);
    post.votesOnPost.push(userId);
    post.ratingOfPost += 1;

    return post.save();
}

exports.voteDown = async (userId, postId) => {
    let post = await Post.findById(postId);

    post.votesOnPost.push(userId);
    post.ratingOfPost -= 1;

    return post.save();
}

exports.updatePost = async (postId, postData) => {
    await Post.findByIdAndUpdate(postId, postData, {runValidators: true});
};

exports.deletePost = async (postId) => await Post.findByIdAndDelete(postId);